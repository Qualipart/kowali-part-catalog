پروژه اندرویدی کوالی پارت

این پروژه یک اپلیکیشن Android WebView با نام «کوالی پارت» می‌سازد که کاتالوگ آنلاین زیر را باز می‌کند:
https://qualipart.github.io/kowali-part-catalog/

برای ساخت خودکار APK در GitHub:
1) فایل kowali-part-android-source.zip را در ریشه مخزن بارگذاری کنید.
2) فایل .github/workflows/build-apk.yml را در همان مسیر مخزن بسازید/جایگزین کنید.
3) در Actions گزینه Build Kowali Part APK را اجرا کنید.
4) بعد از موفقیت، از بخش Artifacts فایل kowali-part-apk را دانلود کنید؛ APK داخل ZIP آرتیفکت است.

توجه: آیکون فعلی موقت است و لوگوی اختصاصی کاربر در این نشست در دسترس فایل‌سازی نبود. برنامه برای نمایش کاتالوگ به اینترنت نیاز دارد. APK تولیدی debug برای تست دستی است و برای انتشار عمومی/Play Store باید نسخه release امضاشده ساخته شود.
